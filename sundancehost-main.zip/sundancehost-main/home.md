# Welcome to Sundance Radio


Sundance Radio Communications has been a leader in two-way communications for both Retail and corporate clients in Calgary for the last 25 years and have a wide range of Kenwood two-way radio products & accessories.

Being a Sales and service shop we have both outbound and inbound staff to complete your sales, service and installation needs to ensure that all of our clients needs are met.




